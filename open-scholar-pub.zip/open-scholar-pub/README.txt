OPEN SCHOLAR PUBLISHING

**These notes outline how to use this plugin to use Wordpress as a repository or platform for an Open Access journal. It creates a custom post with extended fields, organizational taxonomies, and an OAI-PMH metadata component to allow OAI harvesters to collect your material. 



I  EXTENDED FIELDS

A - SERIES TAXONOMY

The series taxonomy defines the categories of publications. It is hierarchical to allow multiple series under a broad definition.

AS A JOURNAL

If you're using this plugin for a single journal, define a single series to handle the install.

AS A REPOSITORY

You can define individual collection tracks, either by using parent groups (often by discipline or college department) with the individual tracks as child Series. (Example: an 'English' parent with the children 'English Papers,' 'Journal of English,' etc.).

B - DISCIPLINES TAXONOMY

This is an optional taxonomy you can utilize to attach discriptive subjects to individual articles. As the plugin is written, these are mostly helpful for harvesting purposes, though one could extend its purpose.

C - SUBMISSIONS

Submissions are the custom post type all of your articles, presentations, or other archived documents are organized under. It can be used to either upload documents, embed items, and/or display original content.

i	Title - The title of the submission
ii	[Editor] - The unlabeled editor is optional. IMPORTANT: if you are not creating a custom template, you must enter the shortcode "[submission]" to get your content to load.
iii	Authors - the author fields detail the submission's author(s). You'll notice an option to create additional author fields for multiple authors.
iv	Journal Information - If your submission is going into a journal, this allows you to assign which volume and issue it should be included in.
v	Publication Date - The original publication date of the submission being uploaded.
vi	Abstract - Summary of the submission being uploaded
vii	Full Text - you can use this editor to place the full text of the submission (probably the primary method for journals), or you could embed things like videos if archiving presentations.
viii	Submission Type - define the type of submission. Default is article.
ix	Upload Submission? - If you have a document to upload, this is where.


II SHORT CODES

A	Index Shortcodes

The plugin comes with some shortcodes that you could impliment to build out an index 
  