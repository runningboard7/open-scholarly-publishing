//Generate date picker from jQuery
jQuery(document).ready(function(){
	jQuery( '.datepicker' ).datepicker();
}
	);

jQuery(document).ready(function($){
$(function() {
  enable_cb();
  $("#osp-assign-issue").click(enable_cb);
});

function enable_cb() {
  if (this.checked) {
    $("#osp-journal-choice").removeAttr("disabled");
  } else {
    $("#osp-journal-choice").attr("disabled", true);
  }
}

}
	);

