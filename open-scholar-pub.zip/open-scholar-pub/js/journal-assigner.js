jQuery(document).ready(function($){
	var ospDrop1 = $( 'select#osp-journal-choose' );
	var pageTitle = $( 'div h2' );
	

	$("select#osp-journal-choose").change(function(){
		
		
			$.ajax({
				url: ajaxurl,
				type: 'POST',

				data: {
					action: 'load_category_one',
					osp_journal_choose: $('#osp-journal-choose').val()
					


				},
				success: function(response) {
					console.log("success");

					$('#osp-load-choice-a').fadeOut(200, function(){
						$('#osp-load-choice-a').empty().append(response).fadeIn();
					});




				},
				error: function(error) {
					console.log("error");
					//$('#osp-load-choice-a').append(response);
					pageTitle.after( '<div id="message">There was an error. Please check your permissions.</div>');
				}
			});
		
	});

	$(document).on("change", '#osp-volume-choose', function(){
		//alert ('osp-joural-choose success');
		$.ajax({
			url: ajaxurl,
			type: 'POST',

			data: {
				action: 'load_category_two',
				osp_volume_choose: $('#osp-volume-choose').val(),
				osp_journal_choose: $('#osp-volume-choose').attr('class')

			},
			success: function(response){
				console.log("success ajax 2");
				$('#osp-load-choice-b').fadeOut(200, function(){
					$('#osp-load-choice-b').empty().append(response).fadeIn();
				});
			},
			error: function(error) {
				console.log("error");
			}
		});
	});

	$(document).on("change", '#osp-issue-choose', function(){
		$.ajax({
			url: ajaxurl,
			type: 'POST',

			data: {
				action: 'load_article_options',
				osp_issue_choose: $('#osp-issue-choose').val(),
				osp_select_journal: $('#osp-select-journal').val(),
				osp_select_volume: $('#osp-select-volume').val()
			},
			success: function(response) {
				console.log("success ajax 3");
				$('#osp-article-sorter').fadeOut(200, function(){
					$('#osp-article-sorter').empty().append(response).fadeIn();
				});
			},
			error: function(error) {
				console.log("error 3");
			}
		});
	});

	$(document).on('click', "ul#custom-type-list", function(){

	var sortList = $( 'ul#custom-type-list' );
	//var animation = $( '#loading-animation' );
	var pageTitle = $( 'div h2' );
	
	sortList.sortable({

		update: function( event, ui ) {
			//animation.show();

			$.ajax({
				url: ajaxurl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'osp_save_sort',
					order: sortList.sortable( 'toArray' ),
					security: OSP_JOURNAL_REORDER.security
					
				},
				success: function( response ) {
					$( 'div#message' ).remove();
					// animation.hide();
					if( true === response.success ) {
						pageTitle.after( '<div id="message" class="updated"><p>' + OSP_JOURNAL_REORDER.success + '</p></div>' );
					} else {
						pageTitle.after( '<div id="message" class="error"><p>1 ' + OSP_JOURNAL_REORDER.failure + '</p></div>' );
					}
					
					
				},
				error: function( error ) {
					$( 'div#message' ).remove();
					// animation.hide();
					pageTitle.after( '<div id="message" class="error"><p>2 ' + OSP_JOURNAL_REORDER.success + '</p></div>' );
				}
			});
		}
	});

});

});

