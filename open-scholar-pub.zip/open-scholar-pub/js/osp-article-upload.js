jQuery(document).ready( function( $ ) {

    $('#osp_upload_document_button').click(function() {

        formfield = $('#osp_upload_document').attr('name');
        tb_show( '', 'media-upload.php?type=image&amp;TB_iframe=true' );
        return false;
    });

    window.send_to_editor = function(html) {

        imgurl = $('img',html).attr('src');
        $('#osp_upload_document').val(imgurl);
        tb_remove();
    }

});

jQuery(document).ready(function($){
$( '#add-row' ).click(function() { 
var rowCount = $('#repeatable-fieldset-one').find('.single-author-row').not(':last-child').size(); 
var newRowCount = rowCount + 1;

var row = $( '.empty-row.screen-reader-text' ).clone(true); 

// Loop through all inputs
row.find('input, text, label').each(function(){ 

    if ( !! $(this).attr('id') )
        $(this).attr('id',  $(this).attr('id').replace('[%s]', '[' + newRowCount + ']') );  

    if ( !! $(this).attr('name') )
        $(this).attr('name',  $(this).attr('name').replace('[%s]', '[' + newRowCount + ']') );  

    if ( !! $(this).attr('for') )
        $(this).attr('for',  $(this).attr('for').replace('[%s]', '[' + newRowCount + ']') );  

});

row.removeClass( 'empty-row screen-reader-text' ).find('.author_rank_number').val('# '+newRowCount);
row.insertBefore( '.empty-row' ); 

// if row count hits 10, hide the add row button 
if ( newRowCount == 10 ) { 
jQuery('#add-row').fadeOut(); 
} 

return false; 
});
        $('.remove-row').on('click', function() {
            $(this).parents('tr').remove();
            return false;
        });
});