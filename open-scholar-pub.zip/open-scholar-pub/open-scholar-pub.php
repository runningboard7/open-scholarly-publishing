<?php
/**
* Plugin Name: Open Scholarly Publications Plugin
* Plugin URI: https://blogs.jccc.edu/bbaile14/open-scholarly-publications-plugin
* Description: This plugin allows you to turn the Wordpress CMS into an appropriate tool for OAI repositories or Open Access journals.
* Author: Barry Bailey
* Author URI: http://blogs.jccc.edu/bbaile14
* Version: 20161221
*/

/**
*Thanks for inspiration and help from the following:
* the dwwp youtube channel: https://www.youtube.com/channel/UCnVv6y1FJ2XbbmXvWO9VBDg/videos
* the DOAJ plugin: http://xplus3.net/2008/11/03/doaj-export/
* the WordPress Stack Overflow community, but particularly user helgatheviking: http://wordpress.stackexchange.com/users/6477/helgatheviking
* Run the Jewels
*/
// Exit for direct
if ( ! defined( 'ABSPATH') ){
	exit;
}

require_once ( plugin_dir_path(__FILE__) . 'osp-cpt.php');
require_once ( plugin_dir_path(__FILE__) . 'osp-render-admin.php');
require_once ( plugin_dir_path(__FILE__) . 'osp-fields.php');
require_once ( plugin_dir_path(__FILE__) . 'osp-shortcodes.php');
require_once ( plugin_dir_path(__FILE__) . 'osp-search-adjust.php');


function osp_admin_enqueue_scripts() {
	global $pagenow, $typenow;

	if ($typenow == 'page') {
		wp_enqueue_style ('osp-admin-css', plugins_url('css/admin-osp.css', __FILE__) );
	}

	if( ($pagenow == 'post.php' || $pagenow == 'post-new.php') && $typenow == 'submission' ) {
		wp_enqueue_style('osp-admin-css', plugins_url( '/css/admin-osp.css', __FILE__ ) );
		wp_enqueue_script( 'osp-admin-js', plugins_url( '/js/admin-osp.js', __FILE__ ), array( 'jquery', 'jquery-ui-datepicker' ), 20160708, true );
		wp_enqueue_script( 'media-upload' );
		wp_enqueue_script( 'thickbox' );
		wp_register_script( 'my-upload', plugins_url( 'js/osp-article-upload.js', __FILE__ ), array( 'jquery', 'media-upload', 'thickbox') );
		wp_enqueue_script( 'my-upload' );
		wp_enqueue_style( 'jquery-style', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/themes/smoothness/jquery-ui.css' );
	}

	if( $pagenow =='edit.php' && $typenow == 'submission' ){
		wp_enqueue_style ('osp-admin-css', plugins_url('css/admin-osp.css', __FILE__) );
		wp_enqueue_script ('journal-assigner', plugins_url( 'js/journal-assigner.js', __FILE__), array( 'jquery', 'jquery-ui-sortable' ), '20160927', true);
		wp_localize_script ('journal-assigner', 'OSP_JOURNAL_REORDER', array(
			'security' => wp_create_nonce( 'osp-submission-reorder' ),
			'success' => __( 'Submissions sort order has been saved.' ),
			'failure' => __( 'There was an error saving the sort order, or you do not have proper permissions.' )
			) );
	}
}

add_action( 'admin_enqueue_scripts', 'osp_admin_enqueue_scripts');


function osp_add_submenu_page(){

	add_submenu_page(
		'edit.php?post_type=submission',
		'Reorder Articles',
		'Reorder Articles',
		'manage_options',
		'reorder_articles',
		'osp_reorder_admin_callback'
	);

}

add_action( 'admin_menu', 'osp_add_submenu_page' );

function osp_add_submenu_help(){
	add_submenu_page(
		'edit.php?post_type=submission',
		'OSP Help',
		'OSP Help',
		'manage_options',
		'osp_help',
		'osp_render_help'
	);
}

add_action( 'admin_menu', 'osp_add_submenu_help');

function osp_create_feed() {
  global $wp_rewrite;
  add_feed('oai', 'osp_oai_feed');
  $wp_rewrite->flush_rules();
}

function osp_oai_feed() {
  include_once('osp-oai-feed.php');
}

add_action('init', 'osp_create_feed'); 