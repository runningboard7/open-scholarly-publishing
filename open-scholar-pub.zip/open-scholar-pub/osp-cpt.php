<?php 
function ospub_register_post_type() {
	$singular = 'Submission';
	$plural = 'Submissions';
	$labels = array(
		'name' => $plural,
		'singular_name' => $singular,
		'add_name' => 'Add New',
		'add_new_item' => 'Add New '. $singular,
		'edit' => 'Edit',
		'edit_item' => 'Edit ' . $singular,
		'new_item' => 'New ' . $singular,
		'view' => 'View ' . $singular,
		'view_item' => 'View ' . $singular,
		'search_term' => 'Search ' . $plural,
		'parent' => 'Parent ' . $singular,
		'not_found' => 'No ' . $plural . ' found',
		'not_found_in_trash' => 'No ' . $plural . ' in Trash'
		);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'publicly_queryable' => true,
		'exclude_from_search' => false,
		'show_in_nav_menus' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_admin_bar' => true,
		'menu_position' => 5,
		'menu_icon' => 'dashicons-welcome-learn-more',
		'can_export' => true,
		'delete_with_user' => false,
		'hierarchical' => false,
		'has_archive' => true,
		'query_var' =>true,
		'capability_type' => 'post',
		'map_meta_cap' => true,
		//'capabilities' => array (),
		'rewrite'	=> array(
			'slug' => 'submissions',
			'with_front' => true, 
			'pages' => true,
			'feeds' => true,

			),
		'supports' => array(
			'title',
			'editor'
			
	
			)

		);
	register_post_type( 'submission', $args);
}
add_action ('init', 'ospub_register_post_type');

/* This function taken from the wordpress codex. Notes left in from codex: very important! */
function osp_rewrite_flush() {
    // First, we "add" the custom post type via the above written function.
    // Note: "add" is written with quotes, as CPTs don't get added to the DB,
    // They are only referenced in the post_type column with a post entry, 
    // when you add a post of this CPT.
    ospub_register_post_type();

    // ATTENTION: This is *only* done during plugin activation hook in this example!
    // You should *NEVER EVER* do this on every page load!!
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'osp_rewrite_flush' );


function osp_register_series_taxonomy() {

	$plural = __( 'Series' );
	$singular = __( 'Series' );


	$labels = array(
		'name'                       => $plural,
        'singular_name'              => $singular,
        'search_items'               => 'Search ' . $plural,
        'popular_items'              => 'Popular ' . $plural,
        'all_items'                  => 'All ' . $plural,

        'edit_item'                  => 'Edit ' . $singular,
        'update_item'                => 'Update ' . $singular,
        'add_new_item'               => 'Add New ' . $singular,
        'new_item_name'              => 'New ' . $singular . ' Name',
        'separate_items_with_commas' => 'Separate ' . $plural . ' with commas',
        'add_or_remove_items'        => 'Add or remove ' . $plural,
        'choose_from_most_used'      => 'Choose from the most used ' . $plural,
        'not_found'                  => 'No ' . $plural . ' found.',
        'menu_name'                  => $plural,
	);

	$args = array(
		'hierarchical'          => true,
        'labels'                => $labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => strtolower( $singular ) ),
	);

	register_taxonomy( strtolower( $singular ), 'submission', $args );

}

add_action( 'init', 'osp_register_series_taxonomy' );



function osp_register_discipline_taxonomy() {

	$plural = __( 'Disciplines' );
	$singular = __( 'Discipline' );


	$labels = array(
		'name'                       => $plural,
        'singular_name'              => $singular,
        'search_items'               => 'Search ' . $plural,
        'popular_items'              => 'Popular ' . $plural,
        'all_items'                  => 'All ' . $plural,

        'edit_item'                  => 'Edit ' . $singular,
        'update_item'                => 'Update ' . $singular,
        'add_new_item'               => 'Add New ' . $singular,
        'new_item_name'              => 'New ' . $singular . ' Name',
        'separate_items_with_commas' => 'Separate ' . $plural . ' with commas',
        'add_or_remove_items'        => 'Add or remove ' . $plural,
        'choose_from_most_used'      => 'Choose from the most used ' . $plural,
        'not_found'                  => 'No ' . $plural . ' found.',
        'menu_name'                  => $plural,
	);

	$args = array(
		'hierarchical'          => true,
        'labels'                => $labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'discipline' ),
	);

	register_taxonomy( 'discipline', 'submission', $args );

}

add_action( 'init', 'osp_register_discipline_taxonomy' );

function osp_add_tax_fields(){
	?>
	<div class="form-field">

		<label for="osp_term_meta[osp_is_journal]"><?php _e('Is Series is Journal?', 'open-scholar-pub'); ?></label>
			<select name="osp_term_meta[osp_is_journal]" id="osp_term_meta[osp_is_journal]">
				<option value="no"><?php _e('No', 'open-scholar-pub'); ?></option>
				<option value="yes"><?php _e('Yes', 'open-scholar-pub'); ?></option>


			</select>

	</div>
	<div class="form-field">

		<label for="osp_term_meta[osp_issn]"><?php _e('ISSN', 'open-scholar-pub'); ?></label>
		<input type="text" name="osp_term_meta[osp_issn]" id="osp_term_meta[osp_issn]" value="">
		<p class="description"><?php _e( 'If your series is a journal and has an ISSN (International Standard Serial Number), enter it here.','open-scholar-pub' ); ?></p>
	</div>
	<div class="form-field">
		<label for="osp_term_meta[osp_meta_rights]"><?php _e('Rights Statement', 'open-scholar-pub'); ?></label>
		<input type="text" name="osp_term_meta[osp_meta_rights]" id="osp_term_meta[osp_meta_rights]" value="">
		<p class="description"><?php _e( 'Please enter a rights statement for your series or journal.','open-scholar-pub' ); ?></p>
	</div>
	<div class="form-field">
		<label for="osp_term_meta[osp_pub_statement]"><?php _e('Publisher', 'open-scholar-pub'); ?></label>
		<input type="text" name="osp_term_meta[osp_pub_statement]" id="osp_term_meta[osp_pub_statement]" value="">
		<p class="description"><?php _e( 'Name the publishing entity for this particular series.','open-scholar-pub' ); ?></p>
	</div>	
	<?php
}
add_action('series_add_form_fields', 'osp_add_tax_fields', 10, 2);

function osp_add_edit_tax_fields($term){
	$t_id = $term->term_id;
	$term_meta = get_option("series_$t_id"); 

	?>
	<tr class="form-field">
	<th scope="row" valign="top"><label for="osp_term_meta[osp_is_journal]"><?php _e( 'Is Series a Journal?', 'open-scholar-pub' ); ?></label></th>
		<td>

			<select name="osp_term_meta[osp_is_journal]" id="osp_term_meta[osp_is_journal]">
				<option value="no"<?php if ( ! empty ( $term_meta['osp_is_journal'] ) ) selected( esc_attr($term_meta['osp_is_journal']), 'no' ); ?>>No</option>
				<option value="yes"<?php if ( ! empty ( $term_meta['osp_is_journal'] ) ) selected( esc_attr($term_meta['osp_is_journal']), 'yes' ); ?>>Yes</option>
			</select>
		</td>
	</tr>
		<tr class="form-field">
	<th scope="row" valign="top"><label for="osp_term_meta[osp_issn]"><?php _e('ISSN', 'open-scholar-pub'); ?></label></th>
		<td>
			<input type="text" name="osp_term_meta[osp_issn]" id="osp_term_meta[osp_issn]" value="<?php echo esc_attr( $term_meta['osp_issn'] ) ? esc_attr( $term_meta['osp_issn'] ) : ''; ?>">
			<p class="description"><?php _e( 'If your series is a journal and has an ISSN (International Standard Serial Number), enter it here.','open-scholar-pub' ); ?></p>
		</td>
	</tr>
	<th scope="row" valign="top"><label for="osp_term_meta[osp_meta_rights]"><?php _e('Rights Statement', 'open-scholar-pub'); ?></label></th>
		<td>
			<input type="text" name="osp_term_meta[osp_meta_rights]" id="osp_term_meta[osp_meta_rights]" value="<?php echo esc_attr( $term_meta['osp_meta_rights'] ) ? esc_attr( $term_meta['osp_meta_rights'] ) : ''; ?>">
			<p class="description"><?php _e( 'Please enter a rights statement for your series or journal.','open-scholar-pub' ); ?></p>
		</td>
	</tr>	
	<th scope="row" valign="top"><label for="osp_term_meta[osp_pub_statement]"><?php _e('Publisher', 'open-scholar-pub'); ?></label></th>
		<td>
			<input type="text" name="osp_term_meta[osp_pub_statement]" id="osp_term_meta[osp_pub_statement]" value="<?php echo esc_attr( $term_meta['osp_pub_statement'] ) ? esc_attr( $term_meta['osp_pub_statement'] ) : ''; ?>">
			<p class="description"><?php _e( 'Name the publishing entity for this particular series.','open-scholar-pub' ); ?></p>
		</td>
	</tr>	

	<?php 
}
add_action('series_edit_form_fields', 'osp_add_edit_tax_fields', 10, 2);

function osp_save_tax_fields($term_id) {
	if (isset($_POST['osp_term_meta']) ){
		$t_id = $term_id;
		$term_meta = get_option("series_$t_id");
		$osp_cat_keys = array_keys($_POST['osp_term_meta']);
		foreach ($osp_cat_keys as $key ){
			if ( isset ( $_POST['osp_term_meta'][$key] ) ) {
				$term_meta[$key] = $_POST['osp_term_meta'][$key];
			}
		}
		update_option("series_$t_id", $term_meta);
	}
}
add_action( 'edited_series', 'osp_save_tax_fields', 10, 2);
add_action( 'create_series', 'osp_save_tax_fields', 10, 2);