<?php 

/* move the editor to the bottom of the page */
add_action( 'edit_form_after_title', 'osp_title_metabox_arrange' );
function osp_title_metabox_arrange() 
{
    global $post, $wp_meta_boxes;

    do_meta_boxes( get_current_screen(), 'normal', $post );

    unset( $wp_meta_boxes['submission']['normal'] );
}

add_action('add_meta_boxes', 'add_author_meta_boxes' );

function add_author_meta_boxes() {
    add_meta_box( 'osp_author_fields', 
        'Authors', 
        'osp_author_repeatable_meta_box_display', 
        'submission', 
        'normal', 
        'high');
}


function osp_author_repeatable_meta_box_display( $post ) { 

	$osp_author_fields = get_post_meta($post->ID, 'osp_author_fields', true); 

	if ( empty( $osp_author_fields ) ){
    	$osp_author_fields[] = array ( 
                                'first_name' => '',
                                'middle_initial' => '',
                                'last_name' => '',
                                'author_email' => '',
                                'author_institution' => '');
	}

	wp_nonce_field( 'osp_author_meta_box_nonce', 'osp_author_meta_box_nonce' ); 
	?> 

	<table id="repeatable-fieldset-one" class="widefat fixed" cellspacing="0" style="width:100%;"> 
		<thead> 
			<tr> 
				<th style="width:15px;" scope="col">#</th> 
				<th style="width:75px;" scope="col">First Name</th> 
				<th width="35px" scope="col">Middle Initial</th>
				<th width="75px" scope="col">Last Name</th> 
				<th width="75px" scope="col">Email</th> 
				<th width="75px" scope="col">Institution</th>  
				<th width="50px" scope="col"></th> 
			</tr> 
		</thead> 
		<tbody> 
		<?php 

		$i = 1; 

		foreach ( $osp_author_fields as $field ) { ?>

			<tr class="single-author-row ui-state-default"> 
	    		<td> 
    				<label for="_authors[<?php echo $i;?>][rank]"> 
    					<input name="_authors[<?php echo $i;?>][rank]" id="_authors[<?php echo $i;?>][rank]" class="author_rank_number" disabled="disabled" type="text" value="# <?php echo $i;?>" /> 
    				</label>    
    			</td> 

    			<td> 
    				<label for "_authors[<?php echo $i; ?>][first_name]">
    					<input name="_authors[<?php echo $i; ?>][first_name]" class="first_name" id="_authors[<?php echo $i; ?>][first_name] "type="text" value="<?php echo esc_attr( $field['first_name']); ?>">
   					</label>
    			</td> 

    			<td> 
     				<label for "_authors[<?php echo $i; ?>][middle_initial]">
    					<input name="_authors[<?php echo $i; ?>][middle_initial]" class="middle_initial" id="_authors[<?php echo $i; ?>][middle_initial] "type="text" value="<?php echo esc_attr( $field['middle_initial']); ?>">
   					</label>
				</td>

    			<td> 
     				<label for "_authors[<?php echo $i; ?>][last_name]">
    					<input name="_authors[<?php echo $i; ?>][last_name]" class="last_name" id="_authors[<?php echo $i; ?>][last_name] "type="text" value="<?php echo esc_attr( $field['last_name']); ?>">
   					</label>
				</td>

				<td>
    				<label for "_authors[<?php echo $i; ?>][author_email]">
    					<input name="_authors[<?php echo $i; ?>][author_email]" class="author_email" id="_authors[<?php echo $i; ?>][author_email] "type="text" value="<?php echo esc_attr( $field['author_email']); ?>">
   					</label>
    			</td> 

    			<td>
    				<label for "_authors[<?php echo $i; ?>][author_institution]">
    					<input name="_authors[<?php echo $i; ?>][author_institution]" class="author_institution" id="_authors[<?php echo $i; ?>][author_institution] "type="text" value="<?php echo esc_attr( $field['author_institution']); ?>">
   					</label>
    			</td> 

    			<td>
    				<a class="button remove-row" href="#">Remove Row</a>
    			</td> 

			</tr> 

			<?php $i++; } ?>


			<tr class="empty-row screen-reader-text single-author-row"> 

    			<td> 
    				<label for="_authors[%s][rank]"> 
    					<input name="_authors[%s][rank]" id="_authors[%s][rank]" class="author_rank_number" disabled="disabled" type="text" value="" /> 
    				</label>    
    			</td> 

    			<td> 
    				<label for="_authors[%s][first_name]"> 
    					<input name="_authors[%s][first_name]" class="first_name" id="_authors[%s][first_name]" type="text" value="" /> 
    				</label> 
    			</td> 

    			<td> 
    				<label for="_authors[%s][middle_initial]"> 
    					<input name="_authors[%s][middle_initial]" class="middle_initial" id="_authors[%s][middle_initial]" type="text" value="" /> 
    				</label> 
				</td>

    			<td> 
    				<label for="_authors[%s][last_name]"> 
    					<input name="_authors[%s][last_name]" class="last_name" id="_authors[%s][last_name]" type="text" value="" /> 
    				</label> 
				</td>
    			
    			<td> 
    				<label for="_authors[%s][author_email]"> 
    					<input name="_authors[%s][author_email]" class="author_email" id="_authors[%s][author_email]" type="text" value="" /> 
    				</label>  
    			</td> 

    			<td>
    				<label for="_authors[%s][author_institution]"> 
    					<input name="_authors[%s][author_institution]" class="author_institution" id="_authors[%s][author_institution]" type="text" value="" /> 
    				</label> 
    			</td> 

			    <td>
				    <a class="button remove-row" href="#">Remove Row</a>
    			</td> 

			</tr> 
		</tbody> 
	</table> 

	<p id="add-row-p-holder"><a id="add-row" class="btn btn-small btn-success" href="#">Insert Another Row</a></p> 

	<?php 
}


add_action('save_post', 'osp_repeatable_meta_box_save', 10, 2); 

function osp_repeatable_meta_box_save($post_id) { 

	if ( ! isset( $_POST['osp_author_meta_box_nonce'] ) || 
		!wp_verify_nonce( $_POST['osp_author_meta_box_nonce'], 'osp_author_meta_box_nonce' ) ) 
		return; 

	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) 
		return; 

	if (!current_user_can('edit_post', $post_id)) 
		return; 

		$clean = array(); 

		if  ( isset ( $_POST['_authors'] ) && is_array( $_POST['_authors'] ) ) :

	    	foreach ( $_POST['_authors'] as $i => $author ){

	    		if( $i == '%s' ){ 

	        		continue;
	    		}



		    	$clean[] = array( 
		        	'first_name' => isset( $author['first_name'] ) ? sanitize_text_field( $author['first_name'] ) : null,
		        	'middle_initial' => isset( $author['middle_initial'] ) ? sanitize_text_field( $author['middle_initial'] ) : null,
		        	'last_name' => isset( $author['last_name'] ) ? sanitize_text_field( $author['last_name'] ) : null,
		        	'author_email' => isset( $author['author_email'] ) ? sanitize_text_field( $author['author_email'] )  : null,
		        	'author_institution' => isset( $author['author_institution'] ) ? sanitize_text_field( $author['author_institution'] ) : null,
		        );
		}

		endif;

		// save author data 
		if ( ! empty( $clean ) ) { 
	    
	    	update_post_meta( $post_id, 'osp_author_fields', $clean ); 
		} else
	    	
	    	delete_post_meta( $post_id, 'osp_author_fields' ); 
}


function osp_add_custom_metabox() {

	add_meta_box(
		'osp_meta',
		__( 'Submission' ),
		'osp_meta_callback',
		'submission',
		'normal',
		'default'
	);

}

add_action( 'add_meta_boxes', 'osp_add_custom_metabox' );

function osp_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'osp_submissions_nonce' );
	$osp_stored_meta = get_post_meta( $post->ID );
	?>

	<div class="meta-row">
		<div class="meta-th">
			<label for="date-created" class="osp-row-title">Publication Date</label>
		</div>
		<div class="meta-td">
			<input type="text" name="date-created" class="osp-row-content datepicker" id="date-created" value="<?php if ( ! empty ( $osp_stored_meta['date-created'] ) ) echo esc_attr( $osp_stored_meta['date-created'] [0]); ?>"/>
		</div>
	</div>


	<div class="meta-row">
		<div class="meta-th">
			<span>Abstract</span>
		</div>
		<div class="meta-editor">
			<?php
			$content = get_post_meta( $post->ID, 'sub-abstract', true );
			$editor = 'sub-abstract' ;
			$settings = array(
				'textarea_rows' => 5,
				'media_buttons' => false,

			);	
			wp_editor($content, $editor, $settings);
			?>
		</div>
	</div>

	<div class="meta-row">
		<div class="meta-th">
			<span>Full Text</span>
		</div>
		<div class="meta-editor">
			<?php
			$content2 = get_post_meta( $post->ID, 'sub-fulltext', true );
			$editor2 = 'sub-fulltext' ;
			$settings2 = array(
				'textarea_rows' => 20,
				'media_buttons' => false,

			);	
			wp_editor($content2, $editor2, $settings2);
			?>
		</div>
	</div>
	
	<div class="meta-row">
		<div class="meta-th">
			<span>Submission Type</span>
		</div>
		<div class="meta-td">
			<select name="osp_submission_type" id="osp_submission_type">
				<option value="article"<?php if ( ! empty ( $osp_stored_meta['osp_submission_type'] ) ) selected( $osp_stored_meta['osp_submission_type'][0], 'article' ); ?>>Article</option>
				<option value="presentation"<?php if ( ! empty ( $osp_stored_meta['osp_submission_type'] ) ) selected( $osp_stored_meta['osp_submission_type'][0], 'presentation' ); ?>>Presentation</option>


			</select>
			
		</div>
	</div>


	<?php
}


function osp_meta_save( $post_id ) {
	// Check save status
	$is_autosave = wp_is_post_autosave( $post_id );
	$is_revision = wp_is_post_revision( $post_id );
	$is_valid_nonce = ( isset( $_POST[ 'osp_submissions_nonce' ] ) && wp_verify_nonce( $_POST[ 'osp_submissions_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
	
	// Exits script depending on save status
	if ($is_autosave || $is_revision || !$is_valid_nonce ){

		return;
	
	}

	

	if ( isset( $_POST['sub-abstract'] ) ) {
		update_post_meta( $post_id, 'sub-abstract', $_POST[ 'sub-abstract' ] );
	}

	if ( isset( $_POST['sub-fulltext'] ) ) {
		update_post_meta( $post_id, 'sub-fulltext', $_POST[ 'sub-fulltext' ] );
	}

	if ( isset( $_POST['date-created'] ) ) {
		update_post_meta( $post_id, 'date-created', sanitize_text_field( $_POST[ 'date-created' ] ) );
	}

	if (isset( $_POST['osp_submission_type'] ) ) {
		update_post_meta( $post_id, 'osp_submission_type', sanitize_text_field( $_POST[ 'osp_submission_type' ] ) );
	}


}

add_action( 'save_post', 'osp_meta_save' );

add_action('add_meta_boxes', 'add_journal_meta_boxes' );

function add_journal_meta_boxes() {
    add_meta_box( 'osp_journal_fields', 
        'Journal Information', 
        'osp_journal_meta_box_display', 
        'submission', 
        'normal', 
        'default');
}

function osp_journal_meta_box_display( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'osp_journal_info_nonce' );
	$osp_journal_meta = get_post_meta( $post->ID );
	$args = array (
		'taxonomy' => 'series',
		'hide_empty' => false,
		);
	$osp_journal_candidates = get_terms( $args );
	?>
	<div class="meta-row">
		<div class="meta-td">
			<p> <strong>Important!</strong> Only use this field to assign volume and issue relationships for your own journal publications.</p>
		</div>
		<div class="meta-td">
			<label>Assign Issue</label>
			<?php 
				$osp_assign_issue = get_post_meta($post->ID, 'osp-assign-issue', true);
				if ($osp_assign_issue == "yes") $osp_assign_issue_checked = 'checked="checked"';
			?>
			<input type="checkbox" name="osp-assign-issue" id="osp-assign-issue" value="yes" <?php echo $osp_assign_issue_checked ?> />
			
			<label>Journal</label>
			<select name="osp-journal-choice" id="osp-journal-choice">
				<option></option>
				<?php 

				foreach ( $osp_journal_candidates as $candidate ) {
					$osp_can_code = esc_attr($osp_journal_meta['osp-journal-choice'][0]);
					$t_id = $candidate->term_id;
					$term_meta = get_option("series_$t_id");
					$osp_jj = $term_meta['osp_is_journal'];
					if($osp_jj == "yes"){
						echo '<option value ="' . $candidate->slug . '" '; 
						if ($osp_can_code == $candidate->slug) {echo 'selected="selected"';}
						if ( ! empty ( $osp_journal_meta['osp-journal-choice'] ) ) selected( $osp_journal_meta['osp-journal-choice'][0], $candidate->slug ); 
						echo '> ' . $candidate->name . '</option>';
					}
				}

				?>
			</select>
			
			<label>Volume</label><input type="text" name="osp-volume" id="osp-volume" value ="<?php if ( ! empty ( $osp_journal_meta['osp-volume'] ) ) echo esc_attr( $osp_journal_meta['osp-volume'][0]); ?>"/>
			
			<label>Issue</label><input type="text" name="osp-issue" id="osp-issue" value ="<?php if ( ! empty ( $osp_journal_meta['osp-issue'] ) ) echo esc_attr( $osp_journal_meta['osp-issue'][0]); ?>"/>

		</div>
	</div>
	<?php
}

function osp_save_journal_info( $post_id ) {
	$is_autosave = wp_is_post_autosave( $post_id );
	$is_revision = wp_is_post_revision( $post_id );
	$is_valid_nonce = ( isset( $_POST[ 'osp_journal_info_nonce' ] ) && wp_verify_nonce( $_POST[ 'osp_journal_info_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
	
	// Exits script depending on save status
	if ($is_autosave || $is_revision || !$is_valid_nonce ){

		return;
	
	}

	if ( isset( $_POST['osp-assign-issue'] ) ) {
		update_post_meta( $post_id, 'osp-assign-issue', sanitize_text_field( $_POST[ 'osp-assign-issue' ] ) );
	}

	if ( isset( $_POST['osp-journal-choice'] ) ) {
		update_post_meta( $post_id, 'osp-journal-choice', sanitize_text_field( $_POST[ 'osp-journal-choice' ] ) );
	}

	if ( isset( $_POST['osp-volume'] ) ) {
		update_post_meta( $post_id, 'osp-volume', sanitize_text_field( $_POST[ 'osp-volume' ] ) );
	}	

	if ( isset( $_POST['osp-issue'] ) ) {
		update_post_meta( $post_id, 'osp-issue', sanitize_text_field( $_POST[ 'osp-issue' ] ) );
	}	
}

add_action('save_post', 'osp_save_journal_info');

function osp_add_file_upload(){
	add_meta_box(
		'wp_custom_attachment',
		'Upload Submission?',
		'wp_custom_attachment',
		'submission',
		'side'
	);
}
add_action('add_meta_boxes', 'osp_add_file_upload');

function wp_custom_attachment($post){
	wp_nonce_field(basename(__FILE__), 'wp_custom_attachment_nonce');
	$osp_attachment_meta = get_post_meta( $post->ID, 'wp_custom_attachment', true );
?>
	<p class="description">
		<?php
		if	(!empty ($osp_attachment_meta)){  
			echo $osp_attachment_meta['url'];
		}else{
			echo 'No submission uploaded.';
		}
		?>
	</p>
<?php
    $html = '<p class="description">';
        $html .= 'Upload your document here.';
    $html .= '</p>';
    $html .= '<input type="file" id="wp_custom_attachment" name="wp_custom_attachment" value="" size="25" />';
     
    echo $html;
}

function osp_save_custom_attachment($post_id){
	    /* --- security verification --- */
 	$is_autosave = wp_is_post_autosave( $post_id );
	$is_revision = wp_is_post_revision( $post_id );
	$is_valid_nonce = ( isset( $_POST[ 'wp_custom_attachment_nonce' ] ) && wp_verify_nonce( $_POST[ 'wp_custom_attachment_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
	
	// Exits script depending on save status
	if ($is_autosave || $is_revision || !$is_valid_nonce ){

		return;
	
	}
     
    // Make sure the file array isn't empty
    if(!empty($_FILES['wp_custom_attachment']['name'])) {
         
        // Setup the array of supported file types. In this case, it's just PDF.
        $supported_types = array('application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/msword' );
         
        // Get the file type of the upload
        $arr_file_type = wp_check_filetype(basename($_FILES['wp_custom_attachment']['name']));
        $uploaded_type = $arr_file_type['type'];
         
        // Check if the type is supported. If not, throw an error.
        if(in_array($uploaded_type, $supported_types)) {
 
            // Use the WordPress API to upload the file
            $upload = wp_upload_bits($_FILES['wp_custom_attachment']['name'], null, file_get_contents($_FILES['wp_custom_attachment']['tmp_name']));
     
            if(isset($upload['error']) && $upload['error'] != 0) {
                wp_die('There was an error uploading your file. The error is: ' . $upload['error']);
            } else {
                add_post_meta($post_id, 'wp_custom_attachment', $upload);
                update_post_meta($post_id, 'wp_custom_attachment', $upload);     
            } // end if/else
 
        } else {
            wp_die("File type not supported. Supported types are pdf, doc, docx, ppt, and pptx.");
        } // end if/else
         
    } // end if
     
} // end save_custom_meta_data
add_action('save_post', 'osp_save_custom_attachment');

function update_edit_form() {
    echo ' enctype="multipart/form-data"';
} // end update_edit_form
add_action('post_edit_form_tag', 'update_edit_form');