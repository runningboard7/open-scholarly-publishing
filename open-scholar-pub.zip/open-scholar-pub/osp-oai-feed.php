<?php
	
	header( 'Content-type: text/xml' );
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n"; 
?>

<OAI-PMH
	xmlns="http://www.openarchives.org/OAI/2.0/"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://www.openarchives.org/OAI/2.0/
		http://www.openarchives.org/OAI/2.0/OAI-PMH.xsd">
	<responseDate><?php date_default_timezone_set('America/Chicago'); $osp_response_date = date('Y-d-m h:i:s a', time()); echo $osp_response_date; ?></responseDate>
	<request verb="ListRecords" metadataPrefix="oai_dc" ></request>
	<ListRecords>
<?php
	$osp_categories = get_terms('series');

	foreach ($osp_categories as $category) {
		if ($category->parent != 0){
		$args = array(
		'post_type' => 'submission',
				'tax_query' => array(

			array(
				'taxonomy' => 'series',
				'field' => 'slug',
				'terms' => $category->slug,
				),

			),
		'orderby' => 'menu_order',
		'order' => 'ASC',
		'post_status' => 'publish',
		'no_found_rows' => true,
		'update_post_term_cache' => false,
		'post_per_post' => 50
	);

	

	$submission_query = new WP_Query( $args );

	while ($submission_query->have_posts() ) : $submission_query->the_post();
	global $post;

	$osp_author_fields = get_post_meta($post->ID, 'osp_author_fields', true);
	$description = get_post_meta($post->ID, 'sub-abstract', true);
	$date_created = get_post_meta($post->ID, 'date-created', true);
	$osp_serieses = wp_get_post_terms($post->ID, 'series');
	$osp_subjects = wp_get_post_terms($post->ID, 'discipline');
	$osp_format = get_post_meta($post->ID, 'osp_submission_type', true);
?>
	<record>
		<header>
			<identifier><?php echo the_permalink(); ?></identifier>
			<datestamp><?php echo the_time(c); ?></datestamp>
			<?php foreach ($osp_serieses as $osp_series){
				?><setSpec><?php echo $osp_series->slug; ?></setSpec><?php
			}
				
			?>
		</header>
		<metadata>
			<oai_dc:dc xmlns:oai_dc="http://www.openarchives.org/OAI/2.0/oai_dc/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.openarchives.org/OAI/2.0/oai_dc/ http://www.openarchives.org/OAI/2.0/oai_dc.xsd"><?php //create dc prefix. I think I'll force this. For now. ?>
				<dc:title> <?php echo the_title(); ?> </dc:title>
				<?php
				
					foreach ($osp_author_fields as $field) { ?>

					<dc:creator><?php echo esc_attr($field['last_name']) ?>, <?php echo esc_attr($field['first_name']) ?></dc:creator>

					<?php
						
					}

				?>
				<dc:description><?php echo $description; ?></dc:description>
				<dc:date><?php echo $date_created; ?></dc:date>
				<dc:type>text</dc:type>
				<dc:format><?php  echo $osp_format; ?></dc:format>
				<dc:identifier><?php echo the_permalink(); ?></dc:identifier>
				<?php
					$osp_attachment_url = get_post_meta($post->ID, 'wp_custom_attachment', true);
					if (! empty ($osp_attachment_url['url'])){
						
						echo "<dc:identifier>" . $osp_attachment_url['url'] . "</dc:identifier>";
					}
				?>

				<?php  
				$t_id = $category->term_id;
				$term_meta = get_option("series_$t_id");
				$osp_jj = $term_meta['osp_pub_statement'];
				if(!empty($osp_jj)){
					?><dc:publisher><?php echo $osp_jj; ?></dc:publisher><?php
				}
				?>
				

				<?php //create subject taxonomy
				 foreach ($osp_subjects as $osp_subject) {
				 	?> <dc:subject><?php echo $osp_subject->name; ?></dc:subject><?php
				 }


				?>
			</oai_dc:dc>
		</metadata>
	</record>
<?php 
	endwhile; 
	wp_reset_query(); 
}
}
?>
</ListRecords>
</OAI-PMH>
