<?php
/* These functions call out and allow the reordering of journal articles. Series are displayed by date. */


function osp_reorder_admin_callback(){

	?>
<div><h2><?php _e( 'Sort Display Order for Journal Submissions', 'open-scholar-pub' ) ?></h2></div>


<div id="osp-journal-sort" class="wrap">
	<div id="osp-pick-journal" class="osp-js-select">
		<label><?php _e( 'Select Journal', 'open-scholar-pub') ?> </label><select name="osp-journal-choose" id="osp-journal-choose">
			<option></option>
			<?php

			$osp_journal_candidates = get_terms( 'series' );

			foreach ( $osp_journal_candidates as $candidate ) {
				$t_id = $candidate->term_id;
				$term_meta = get_option("series_$t_id");
				$osp_jj = $term_meta['osp_is_journal'];
				if($osp_jj =="yes"){
					echo '<option value ="' . $candidate->slug . '" '; 
					echo ' class="osp-single-journal-option"> ' . $candidate->name . '</option>';
				}
			}


			?>

		</select>
	</div>
	<div id="osp-load-choice-a" class="osp-js-select">

	</div>
	<div id="osp-load-choice-b" class="osp-js-select">
		
	</div>
	<div id="osp-article-sorter" class="osp-sorter">

	</div>
</div>

<?php
wp_reset_postdata();
}


function osp_get_category_one(){

	$slug = $_POST['osp_journal_choose'];

		//find posts with slug attached
	$args2 = array(
		'post_type' => 'submission',
		'tax_query' => array(
			array(
				'taxonomy' => 'series',
				'field' => 'slug',
				'terms' => $_POST['osp_journal_choose'],
				),
			),
		'meta_query' => array(
			array(
				'key' => 'osp-assign-issue',
				'value' => 'yes',
				),
			array(
				'key' => 'osp-journal-choice',
				'value' => $_POST['osp_journal_choose'],
				),
			),
		'orderby' => 'menu_order',
		'order' => 'ASC',
		'post_status' => 'publish',
		'no_found_rows' => true,
		'update_post_term_cache' => false,
		'post_per_post' => 50,


		);

	$osp_first_drops = new WP_Query( $args2 );
	$osp_volume_array = array();
	?>
	<div class="wrap">


		<?php
		if ($osp_first_drops->have_posts() ) : 
			while  ($osp_first_drops->have_posts() ) : $osp_first_drops->the_post(); 
		global $post;
		$osp_volume = get_post_meta($post->ID, 'osp-volume', true);
		if(! empty($osp_volume)){	
			$osp_volume_array[] = $osp_volume; 
		}
		?>
		
	<?php endwhile ?>
</select>
<?php else: ?>
	<p>No articles</p>
<?php endif; 
if(!empty($osp_volume_array)){
	$osp_volume_array = array_unique($osp_volume_array);

	echo "<label>Select Volume </label><select id='osp-volume-choose' name='osp-volume-choose' class='" . $slug . "'>";
	echo "<option></option>";
	foreach($osp_volume_array as $osp_display_volume){
		echo "<option value='" . $osp_display_volume . "'>" . $osp_display_volume . "</option>";
	}
	echo "</select>";
} else {
	?><p> <?php _e('osp_volume_array is empty', 'open-scholar-pub') ?></p><?php
}
?>
</div>
<?php 
wp_reset_postdata();
exit;
} 
add_action( 'wp_ajax_nopriv_load_category_one', 'osp_get_category_one' );
add_action( 'wp_ajax_load_category_one', 'osp_get_category_one' );

function osp_get_category_two(){

	$slug = $_POST['osp_journal_choose'];
	$args3 = array(
		'post_type' => 'submission',
		'tax_query' => array(
			array(
				'taxonomy' => 'series',
				'field' => 'slug',
				'terms' => $_POST['osp_journal_choose'],
				),
			),
		'meta_query' => array(
			array(
				'key' => 'osp-assign-issue',
				'value' => 'yes',
				),
			array(
				'key' => 'osp-journal-choice',
				'value' => $_POST['osp_journal_choose'],
				),
			array(
				'key' => 'osp-volume',
				'value' => $_POST['osp_volume_choose'],
				),
			),
		'orderby' => 'menu_order',
		'order' => 'ASC',
		'post_status' => 'publish',
		'no_found_rows' => true,
		'update_post_term_cache' => false,
		'post_per_post' => 50,
		);

	$osp_issue_drops = new WP_Query( $args3 );
	$osp_issue_array = array();
	?>
	<div class="wrap">

		
		<?php
		if ($osp_issue_drops->have_posts() ) : 
			while  ($osp_issue_drops->have_posts() ) : $osp_issue_drops->the_post(); 
		global $post;
		$osp_issue = get_post_meta($post->ID, 'osp-issue', true);
		if(! empty($osp_issue)){	
			$osp_issue_array[] = $osp_issue; 
		}
		?>

	<?php endwhile ?>
</select>
<?php else: ?>
	<p>No articles</p>
	<?php endif; 
	if(!empty($osp_issue_array)){
		$osp_issue_array = array_unique($osp_issue_array);
		natsort($osp_issue_array);
	 	
		
		echo "<label>Select Issue </label><select id='osp-issue-choose' name='osp-issue-choose' class='" . $slug . "'>";
		echo "<option></option>";
		foreach($osp_issue_array as $osp_display_issue){
			echo "<option value='" . $osp_display_issue . "'>" . $osp_display_issue . "</option>";
		}
		echo "</select>";
		echo "<input type='hidden' id='osp-select-journal' name='osp-select-journal' value='" . $slug . "'/>";
		echo "<input type='hidden' id='osp-select-volume' name='osp-select-volume' value='" . $_POST['osp_volume_choose'] . "'/>";
	} else {
		?><p> <?php _e('osp_volume_array is empty', 'open-scholar-pub') ?></p><?php
	}
	?>
</div>
<?php 
wp_reset_postdata();


exit;
} 
add_action( 'wp_ajax_nopriv_load_category_two', 'osp_get_category_two' );
add_action( 'wp_ajax_load_category_two', 'osp_get_category_two' );

function osp_list_articles(){
	$osp_article_param = $_POST['osp_issue_choose'];
	$osp_journal_param = $_POST['osp_select_journal'];

		$args4 = array(
		'post_type' => 'submission',
		'tax_query' => array(
			array(
				'taxonomy' => 'series',
				'field' => 'slug',
				'terms' => $_POST['osp_select_journal'],
				),
			),
		'meta_query' => array(
			array(
				'key' => 'osp-assign-issue',
				'value' => 'yes',
				),
			array(
				'key' => 'osp-journal-choice',
				'value' => $_POST['osp_select_journal'],
				),
			array(
				'key' => 'osp-volume',
				'value' => $_POST['osp_select_volume'],
				),
			array(
				'key' => 'osp-issue',
				'value' => $_POST['osp_issue_choose'],
				),
			),

		'orderby' => 'menu_order',
		'order' => 'ASC',
		'post_status' => 'publish',
		'no_found_rows' => true,
		'update_post_term_cache' => false,
		'post_per_post' => 50,
		);	
		$osp_listing = new WP_Query( $args4 );
		?>
		<div id="sumission-sort" class="wrap">
		<div id="icon-submission-admin" class="icon32"><br/></div>
		
		<?php
		if ($osp_listing->have_posts() ) : ?>
		<ul id="custom-type-list">
			<?php while  ($osp_listing->have_posts() ) : $osp_listing->the_post(); ?>
			<li id="<?php esc_attr(the_id()); ?>"><?php the_title(); ?></li>
		<?php endwhile ?>
	</ul>
<?php else: ?>
	<p>No articles</p>
<?php endif; ?>
</div> <?php 
wp_reset_postdata();
exit;
}
add_action( 'wp_ajax_nopriv_load_article_options', 'osp_reorder_articles' );
add_action( 'wp_ajax_load_article_options', 'osp_list_articles' );


function osp_save_reorder() {
	if (! check_ajax_referer('osp-submission-reorder', 'security')) {
		return wp_send_json_error( 'Error: invalid nonce.' );
	}

	if (! current_user_can('manage_options') ) {
		return wp_send_json_error('You do not have the permissions to do this.');
	}

	$osp_order = $_POST['order'];
	$osp_counter = 0;
	foreach( $osp_order as $item_id ) {
		$post = array(
			'ID' => (int)$item_id,
			'menu_order' => $osp_counter,
		);
		wp_update_post( $post );
		$osp_counter++;
	}
	wp_send_json_success( 'Post Saved.' );
}
add_action( 'wp_ajax_nopriv_osp_save_sort', 'osp_save_reorder' );
add_action( 'wp_ajax_osp_save_sort', 'osp_save_reorder' );

function osp_render_help(){
	?>
	<div id="osp_help_display">
		<h1><?php _e( 'Open Scholar Publishing Help', 'open-scholar-pub' ) ?></h1>
		<ol>
			<li><a href="#taxonomies"><?php _e( 'Using Series and Discipline Taxonomies', 'open-scholar-pub' ) ?></a></li>
			<li><a href="#fields"><?php _e( 'Using Submission Fields', 'open-scholar-pub' ) ?></a></li>
			<li><a href="#shortcodes"><?php _e( 'Shortcodes', 'open-scholar-pub' ) ?></a></li>
			<li><a href="#reorder"><?php _e( 'Reorder Articles', 'open-scholar-pub' ) ?></a></li>
		</ol>

		<a name="taxonomies"> </a>
		<h3><?php _e('Using Series and Discipline Taxonomies', 'open-scholar-pub') ?></h3>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/uhkORHWZXJA" frameborder="0" allowfullscreen></iframe>
		<p><?php _e('Series function much like regular taxonomies. Parents can represent research or academic groups if you choose to use them with children series as specific collections, or as collections or journals on their own. Here are descriptions of the custom taxonomy fields included.', 'open-scholar-pub') ?></p>
		<ul class="osp_help_list">
			<li><strong><?php _e('Check if Series is Journal: ', 'open-scholar-pub') ?></strong><?php _e('Default is no, but move to yes if this series is journal', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('ISSN: ', 'open-scholar-pub') ?></strong><?php _e('If this is a journal and you have an ISSN for it, enter it here.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('Rights Statement: ', 'open-scholar-pub') ?></strong><?php _e('For any journal or series, use this statement to declare institutional, departmental, author, or other ownership and/or usage rights.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('Publisher: ', 'open-scholar-pub') ?></strong><?php _e('Declare a publisher for the journal or series. This could be your institution, the appropriate department or research group, or whatever is appropriate.', 'open-scholar-pub' ) ?></li>
		</ul>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/ivENRQI1mMk" frameborder="0" allowfullscreen></iframe>
		<p><?php _e('The Discipline taxonomy is a straightforward tagging of the article by a relevant discipline. This is not a required field but may help you in organizing or leveraging a controlled vocabulary of research subjects. Assigned disciplines will display in the applicable submission pages when using the default shortcode.', 'open-scholar-pub') ?></p>
		<a name="fields"> </a>
		<h3><?php _e('Using Submission Fields', 'open-scholar-pub') ?></h3>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/6MBX85aRa74" frameborder="0" allowfullscreen></iframe>
		<ul class="osp_help_list">
			<li><strong><?php _e('Title: ', 'open-scholar-pub') ?></strong><?php _e('The default title, like in a regular page or post.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('Authors: ', 'open-scholar-pub') ?></strong><?php _e('Enter author&#39;s name, email, and institution. Allows for multiple authors.' , 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('Journal Information: ', 'open-scholar-pub') ?></strong><?php _e('For hosting your own journal. Assign this submission to the appropriate journal, volume, and issue.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('Publication Date: ', 'open-scholar-pub') ?></strong><?php _e('The date of the submission&#34;s original publication.', 'open-scholar-pub' ) ?></li>		
			<li><strong><?php _e('Abstract: ', 'open-scholar-pub') ?></strong><?php _e('Summary of submission or abstract for article. ', 'open-scholar-pub' ) ?></li>			
			<li><strong><?php _e('Full Text: ', 'open-scholar-pub') ?></strong><?php _e('This is where you would embed a presentation,video, or submit the HTML version of the text. ', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('Series: ', 'open-scholar-pub') ?></strong><?php _e('Select the appropriate series and, if applicable, sub-series. Journal titles are also listed as series here. Though you can add a series on the fly, please see the information about series in this help page for more information.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('Disciplines: ', 'open-scholar-pub') ?></strong><?php _e('Completely optional, feel free to assign disciplines to your submissions. They will appear in the article (as generated by shortcode) and metadata.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('Upload Submission: ', 'open-scholar-pub') ?></strong><?php _e('If you are using this as a repository or perhaps want to store PDFs of the print version of your journal, you can utilize the Upload Submission option to include the document.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('The Wordpress Editor: ', 'open-scholar-pub') ?></strong><?php _e('At the bottom of the submission (though it can be moved) is the WordPress default editor. If you are not using custom templates to publicly display fields, you can submit the shortcode <strong>[submission]</strong> to generate the submission fields in its own page.', 'open-scholar-pub' ) ?></li>
		</ul>
		<a name="shortcodes"> </a>
		<h3><?php _e('Shortcodes', 'open-scholar-pub') ?></h3>
		<p><?php _e('These shortcodes are meant to help control and display content for different situations, for users with all levels of HTML, CSS, and WordPress experience. Below are some descriptions and options with these shortcodes.', 'open-scholar-pub') ?></p>
		<h4><?php _e('[submission]', 'open-scholar-pub') ?></h4>
		<p><?php _e('When entering a new submission, the WordPress editor (by default at the bottom) can have the shortcode [submission] added to it to generate the article.', 'open-scholar-pub') ?></p>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/JSTOAqW3TYQ" frameborder="0" allowfullscreen></iframe>
		<h4><?php _e('[index_list] and [series_display param=&#39;osp_series_cat&#39;]', 'open-scholar-pub') ?></h4>
		<p><?php _e('When used as a repository of multiple series and/or journals, these two shortcodes work together to create an index of your collections, and link to a page that generates the appropriate series.', 'open-scholar-pub') ?></p>
		<ul class="osp_help_list">
			<li><?php _e('On the homepage for your repository, include the shortcode [index_list]', 'open-scholar-pub') ?></li>
			<li><?php _e('Create a page, and change its permilink to &#34;s&#34;. Leave the title field blank', 'open-scholar-pub') ?></li>
			<li><?php _e('On the page you have named &#34;s&#34;, type into the editor the shortcode [series_display param=&#39;osp_series_cat&#39;]', 'open-scholar-pub') ?></li>
			<li><?php _e('You should now be able to open your main page to an index of series, and links should take you to your &#34;s&#34; page with the appropriate series loaded.', 'open-scholar-pub') ?></li>
		</ul>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/OfwSqKMHv4w" frameborder="0" allowfullscreen></iframe>
		<h4><?php _e('display_journal', 'open-scholar-pub') ?></h4>
		<p><?php _e('If you would like to create a custom landing page for your journal, this shortcode allows you to implement the pieces that may be relevant to you. At its simplest, it can generate an index to include in your page. At its most complicated, it can function in the same way the [series_display] shortcode would for a journal. Completely utilized, the shortcode would look like <em>[display_journal title="yes" description="yes" issn="yes" param="journal-slug"]</em>', 'open-scholar-pub') ?></p>
		<ul class="osp_help_list">
			<li><strong><?php _e('[display_journal] ', 'open-scholar-pub') ?></strong><?php _e('This is the shortcode to invoke. To work, it will need AT LEAST the field, param', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('param=&#34;journal-slug&#34; (required): ', 'open-scholar-pub') ?></strong><?php _e('This is the only required field to function properly, as it envokes the journal you want to display. Replace journal-slug with the journal&#39;s slug.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('title=&#34;yes&#34;: ', 'open-scholar-pub') ?></strong><?php _e('If you would like to auto-generate the title, leave the field in the page blank and include this variable.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('issn=&#34;yes&#34;: ', 'open-scholar-pub') ?></strong><?php _e('Including this will display the ISSN field. Leave out if you do not have one.', 'open-scholar-pub' ) ?></li>
			<li><strong><?php _e('description=&#34;yes&#34;: ', 'open-scholar-pub') ?></strong><?php _e('Include to display description. Note, if you are writing your own introduction and use the shortcode to generate the title, the description will appear above the title. It is best to utilize the page title field if foregoing this variable.', 'open-scholar-pub' ) ?></li>
		</ul>
		<a name="reorder"> </a>
		<h3><?php _e('Reorder Articles', 'open-scholar-pub') ?></h3>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/patV9_jC_tM" frameborder="0" allowfullscreen></iframe>
		<p><?php _e('While a non-journal series is ordered by the original publication date, journals can have their entries reordered via this feature. The steps are pretty simple:', 'open-scholar-pub') ?></p>
		<ol>
			<li><?php _e( 'Select the Journal', 'open-scholar-pub' ) ?></li>
			<li><?php _e( 'Select the Volume', 'open-scholar-pub' ) ?></li>
			<li><?php _e( 'Select the Issue', 'open-scholar-pub' ) ?></li>
			<li><?php _e( 'Click the articles and drag them into the order you prefer. After every drag, it will save your order.', 'open-scholar-pub' ) ?></li>
		</ol>
	</div>
	<?php
}