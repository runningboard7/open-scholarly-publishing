<?php
// Code builds submission body
function osp_article_build_shortcode($post){
	$osp_article = "";
	wp_enqueue_style('osp-admin-css', plugins_url('css/osp-article-display.css', __FILE__) );
	$get_submission_data = get_post_meta( get_the_ID() );
	$get_authors = get_post_meta( get_the_ID(), 'osp_author_fields', true );
	$osp_article .= "<div id='osp-author-statement'>";
	foreach ($get_authors as $osp_author){
		$first_name = esc_attr($osp_author['first_name']); 
		$middle_init = esc_attr($osp_author['middle_initial']);
		$last_name = esc_attr($osp_author['last_name']); 
		$author_email = esc_attr($osp_author['author_email']); 
		$author_institution = esc_attr($osp_author['author_institution']); 
		$osp_auth_build = "<p>";
		if(!empty($author_email)){$osp_auth_build .= "<a href='mailto:" . $author_email . "'>";}
		if(!empty($first_name)){$osp_auth_build .=  $first_name;} 
		if(!empty($middle_init)){$osp_auth_build .=  " " . $middle_init;}
		if(!empty($last_name)){$osp_auth_build .= " " . $last_name;}
		if(!empty($author_email)){$osp_auth_build .= "</a>";}
		if(!empty($author_institution)){$osp_auth_build .= ", <em>" . $author_institution . "</em>  " . "</p>";}
		
		$osp_article .=$osp_auth_build;
	}
	$osp_article .= "</div>";
	if (! empty ($get_submission_data['wp_custom_attachment'])){
		$osp_attachment_url = get_post_meta(get_the_ID(), 'wp_custom_attachment', true);
		$osp_article .= "<div id='osp-download-submission'><a id='osp-download-button' href='" . $osp_attachment_url['url'] . "''>Download</a></div>";
	}
	$date_created = esc_attr($get_submission_data['date-created'] [0]); 
	$abstract = ($get_submission_data['sub-abstract'] [0]);
	$abstract = apply_filters('the_content', $abstract);
	$abstract = str_replace( ']]>', ']]&gt;', $abstract );
	$fulltext = ($get_submission_data['sub-fulltext'] [0]);
	$fulltext = apply_filters('the_content', $fulltext);
	$fulltext = str_replace( ']]>', ']]&gt;', $fulltext );
	$osp_article .=	"<div id='osp-print-abstract'><h3>Abstract</h3><p>" . $abstract . "</p>";
		$osp_subjects = wp_get_post_terms(get_the_ID(), 'discipline');
		if(!empty($osp_subjects)){
			$osp_article .= "<p class='osp-disciplines'>Disciplines: ";
			foreach ($osp_subjects as $osp_subject) {
				$osp_list_subjects .= ", " . $osp_subject->name;
			}
			$osp_list_subjects = ltrim($osp_list_subjects, ",");
			$osp_article .= $osp_list_subjects . "</p>";
		}
	$osp_article .= "</div>
	<div id='osp-the-submission'>" . $fulltext . "</div>";
	

//Citation Builder

	$citation_builder = "<div id='osp-citation-builder'><h3>MLA Citation</h3>";
	$ci=0;
	$get_authors_cite = get_post_meta( get_the_ID(), 'osp_author_fields', true );
	foreach ($get_authors_cite as $osp_autho){
		$first_name = esc_attr($osp_autho['first_name']); 
		$middle_init = esc_attr($osp_autho['middle_initial']);
		$last_name = esc_attr($osp_autho['last_name']); 
		$ci++;
		if(!empty($last_name)){$osp_cit_ln[$ci] =  $last_name;}
		if(!empty($first_name)){$osp_cit_fn[$ci] =  $first_name;}
		
	}
	$authco = count($get_authors_cite);

	if ( $authco == 1) {
		$osp_citeauth = $osp_cit_ln[1] . ", " . $osp_cit_fn[1] . ". ";
	}

	if ($authco == 2){
		$osp_citeauth = $osp_cit_ln[1] . ", " . $osp_cit_fn[1] . ", and " . $osp_cit_fn[2] . " " . $osp_cit_ln[2] . ". ";
	}



	if ( $authco >= 3) {
		$osp_citeauth = $osp_cit_ln[1] . ", " . $osp_cit_fn[1] . ", et al. ";
	}

	$osp_serieses = wp_get_post_terms(get_the_ID(), 'series');
	


	// Get Series
	foreach ($osp_serieses as $osp_series) {
		if ($osp_series->parent <> 0){
			$osp_citeser = $osp_series->name;
		}
	}

	$osp_citedate = date('j M. Y. ', strtotime(esc_attr(get_post_meta(get_the_ID(), 'date-created', true))));
	$osp_citeurl = get_permalink();
	$osp_url_edit = array('http://', 'https://');
	$osp_citeurl = str_replace($osp_url_edit, '', $osp_citeurl);
	$osp_mla = '<p class="osp_mla_citation">' . $osp_citeauth . '"' . get_the_title() . '." <em>' . $osp_citeser . ',</em> ' . $osp_citedate . ' ' . $osp_citeurl . '.</p>';

	$citation_builder .= $osp_mla;
	
	$citation_builder .= "</div>";
	$citation_builder = str_replace( ']]>', ']]&gt;', $citation_builder );
	$osp_article .= $citation_builder;


	// END citation code

	return $osp_article;
}

add_shortcode( 'submission', 'osp_article_build_shortcode');

//Code creates repository index

function osp_build_index( $atts, $content = null ) {
wp_enqueue_style('osp-admin-css', plugins_url('css/osp-index-display.css', __FILE__) );
	$atts = shortcode_atts( 

		array(

			'title' => 'Research Areas',
			'url' => 's',

			), $atts

		);
	$osp_s_url = $atts['url'];
	$osp_p_title = esc_html__( $atts[ 'title' ]);
	$categories = get_terms( 'series' );

	if( ! empty( $categories ) && ! is_wp_error( $categories ) ) {

		$displaylist = '<div id="osp-category-list">';

		$displaylist .= '<h2>' .  $osp_p_title . '</h2>';

		foreach( $categories  as $category ) {

			if ($category->parent == 0){

				$displaylist .= '<h3>' . esc_html__( $category->name ) . '</h3>';
				$special_id = $category->term_id;
				$categories2 = get_terms( 'series' );
				$displaylist .= '<ul>';
				foreach($categories2 as $category2 ) {
					if ($category2->parent == $special_id){										
						$displaylist .= '<li class="osp-category">';
						$displaylist .= '<a href="/'. $osp_s_url.'/' . $category2->slug . '">'; //UPDATED for child theme
						$displaylist .= esc_html__( $category2->name ) . '</a></li>';
					}
				}
				$displaylist .= '</ul>';

			}

		}

		$displaylist .= '</div>';

	}

	return $displaylist;
}
add_shortcode( 'index_list', 'osp_build_index');

function osp_build_test(){
	$args = array( 'post_type' => 'submission' );
	$postslist = get_posts( $args );
	foreach ( $postslist as $post ) :
		setup_postdata( $post ); ?> 
	<div>
		<?php the_date(); ?>
		<br />
		<?php the_title(); ?>   
		<?php the_excerpt(); ?>
	</div>
	<?php
	endforeach; 
	wp_reset_postdata();
}

add_shortcode( 'pub_test', 'osp_build_test');

function osp_series_page($atts){
	wp_enqueue_style('osp-admin-css', plugins_url('css/osp-series-page.css', __FILE__) );

    extract( shortcode_atts( array(
        'param' => 'param',
    ), $atts ) );

	$osp_series_slug = sanitize_text_field($_GET[$param]);
	//$osp_output .= '<h2>' . $osp_series_slug . '</h2>';
	$osp_series_terms = get_term_by('slug', $osp_series_slug, 'series');
	//var_dump($osp_series_terms);
	$osp_output .= '<header><h1 class="entry-title">' . $osp_series_terms->name . '</h1></header>';
	
	$t_id = $osp_series_terms->term_id;
	$term_meta = get_option("series_$t_id");
	$osp_issn = $term_meta["osp_issn"];
	$osp_series_desc = $osp_series_terms->description;
	if (!empty($osp_series_desc)){
		$osp_output .= '<div id="osp-series-description"><p>' . $osp_series_desc . '</p></div>';
	}
	if (!empty($osp_issn)){
		$osp_output .= '<div id="osp-issn"><p>ISSN: ' . $osp_issn . '</p></div>';
	}
	$args = array(

		'post_type' => 'submission',
		'tax_query' => array(
			array(
				'taxonomy' => 'series',
				'field' => 'slug',
				'terms' => $osp_series_slug,
				),
			),
		'post_status' => 'publish',
		'no_found_rows' => true,
		'update_post_term_cache' => false,						
	);
	$osp_determines = new WP_Query($args);
	if ($osp_determines->have_posts()){
		$osp_j_check = array();
		while($osp_determines->have_posts()) : $osp_determines->the_post();
		global $post;
		//$osp_output .= '<p>loop</p>';
		$osp_journal_check = get_post_meta($post->ID, 'osp-assign-issue', true); 		
		$osp_right_journal = get_post_meta($post->ID, 'osp-journal-choice', true);
		if(!empty($osp_journal_check) && ($osp_right_journal == $osp_series_slug)){

			$osp_j_check[] = $osp_journal_check;

		}
		endwhile;
	} wp_reset_postdata();

	if(!empty($osp_j_check)){
		$osp_output .= '<div id="osp-journal-display">';
		$args2 = array(
			'post_type' => 'submission',
			'tax_query' => array(
				array(
					'taxonomy' => 'series',
					'field' => 'slug',
					'terms' => $osp_series_slug,
					),
				),

			'meta_query' => array(
				'volume_clause' => array(
					'key' => 'osp-volume',
					), 
				'issue_clause' => array(
					'key' => 'osp-issue',
					),
				'date_clause' => array(
					'key' => 'date-created',
					),
				),
			'orderby' => array(

				'volume_clause' => 'ASC',
				'issue_clause' => 'ASC',
				'menu_order' => 'ASC',

				),
			'post_status' => 'publish',
			'no_found_rows' => true,
			'update_post_term_cache' => false,
			'post_per_post' => 50,
		);
			$osp_j_v_check = "";
			$osp_j_i_check = "";
			$osp_series_type = new WP_Query($args2);
			if ($osp_series_type->have_posts()) {
				while($osp_series_type->have_posts()) : $osp_series_type->the_post();

					global $post;
					if (($osp_j_v_check == "") || ($osp_j_v_check != get_post_meta($post->ID, 'osp-volume', true))){
						$osp_output .= '<h3> Volume ' . get_post_meta($post->ID, 'osp-volume', true) . '</h3>'; 
						$osp_j_v_check = get_post_meta($post->ID, 'osp-volume', true);
					}

					if (($osp_j_i_check == "") || ($osp_j_i_check != get_post_meta($post->ID, 'osp-issue', true))){
						$osp_output .= '<h4> Issue ' . get_post_meta($post->ID, 'osp-issue', true) . '</h4>'; 
						$osp_j_i_check = get_post_meta($post->ID, 'osp-issue', true);
					}

					$osp_output .= '<p><a href="'.  get_permalink() .'">' . get_the_title() . '</a>'; 
					$osp_authors = get_post_meta($post->ID, 'osp_author_fields', true);
					$osp_auth_output ="";
					foreach ($osp_authors as $osp_author) {
						$osp_auth_output .= ', ' . esc_attr($osp_author['first_name']) . ' ' . esc_attr($osp_author['middle_initial']) . ' ' . esc_attr($osp_author['last_name']);
					}
					$osp_auth_output = ltrim($osp_auth_output, ",");
					
					$osp_output .= $osp_auth_output . '</p>'; 

				endwhile;
			}
			$osp_output .= '</div>';
			wp_reset_postdata();
	}

	if(empty($osp_j_check)){
		
		$args3 = array(
			'post_type' => 'submission',
			'tax_query' => array(
				array(
					'taxonomy' => 'series',
					'field' => 'slug',
					'terms' => $osp_series_slug,
					),
				),

			'meta_query' => array(
				'create_date_clause' => array(
					'key' => 'date-created',
					), 
				),
			'meta_key' => 'date-created',
			'orderby' => 'create_date_clause',

				'order' => 'DESC',

				
			'post_status' => 'publish',
			'no_found_rows' => true,
			'update_post_term_cache' => false,
			'post_per_post' => 50,
		);

		$osp_series_type2 = new WP_Query($args3);
		$osp_y_check = "";	
		if($osp_series_type2->have_posts()){
			$osp_output .= '<div id="osp-series-display">';
			while($osp_series_type2->have_posts()) : $osp_series_type2->the_post();
				
				global $post;

				if($osp_y_check != date('Y', strtotime(get_post_meta($post->ID, 'date-created', true)))){

					$osp_y_check = date('Y', strtotime(get_post_meta($post->ID, 'date-created', true)));
					$osp_output .= '<h2>' . $osp_y_check . '</h2>';

				}
				$osp_output .= '<p><a href="'.  get_permalink() .'">' . get_the_title() . '</a>'; 
				$osp_authors = get_post_meta($post->ID, 'osp_author_fields', true);
				$osp_auth_output ="";
				foreach ($osp_authors as $osp_author) {
					$osp_auth_output .= ', ' . esc_attr($osp_author['first_name']) . ' ' . esc_attr($osp_author['middle_initial']) . ' ' . esc_attr($osp_author['last_name']);
				}	
				$osp_auth_output = ltrim($osp_auth_output, ",");
				$osp_output .= $osp_auth_output . '</p>'; 
			endwhile;
			$osp_output .= '</div>';
		}
		wp_reset_postdata();
	}

	return $osp_output;
}
add_shortcode('series_display', 'osp_series_page');


function osp_single_journal($atts){
	wp_enqueue_style('osp-admin-css', plugins_url('css/osp-single-journal.css', __FILE__) );
    extract( shortcode_atts( array(
        'param' => 'no param',
        'title' => 'no title',
        'description' =>'no description',
        'issn' =>'no issn',

    ), $atts ) );

	$osp_series_slug = $atts['param'];
	//$osp_output .= '<h2>' . $osp_series_slug . '</h2>';
	$osp_series_terms = get_term_by('slug', $osp_series_slug, 'series');
	//var_dump($osp_series_terms);
	if (!empty($atts['title'])){
		$osp_output .= '<header><h1 class="entry-title">' . $osp_series_terms->name . '</h1></header>';
	}
	$t_id = $osp_series_terms->term_id;
	$term_meta = get_option("series_$t_id");
	$osp_issn = $term_meta["osp_issn"];
	$osp_series_desc = $osp_series_terms->description;
	if (!empty($atts['description'])){
		$osp_output .= '<div id="osp-series-description"><p>' . $osp_series_desc . '</p></div>';
	}
	if (!empty($atts['issn'])){
		$osp_output .= '<div id="osp-issn"><p>ISSN: ' . $osp_issn . '</p></div>';
	}
	$args = array(

		'post_type' => 'submission',
		'tax_query' => array(
			array(
				'taxonomy' => 'series',
				'field' => 'slug',
				'terms' => $osp_series_slug,
				),
			),
		'post_status' => 'publish',
		'no_found_rows' => true,
		'update_post_term_cache' => false,						
	);
	$osp_determines = new WP_Query($args);
	if ($osp_determines->have_posts()){
		$osp_j_check = array();
		while($osp_determines->have_posts()) : $osp_determines->the_post();
		global $post;
		//$osp_output .= '<p>loop</p>';
		$osp_journal_check = get_post_meta($post->ID, 'osp-assign-issue', true); 		
		$osp_right_journal = get_post_meta($post->ID, 'osp-journal-choice', true);
		if(!empty($osp_journal_check) && ($osp_right_journal == $osp_series_slug)){

			$osp_j_check[] = $osp_journal_check;

		}
		endwhile;
	} wp_reset_postdata();
	//$osp_output .= '<h2> test ' . $osp_series_slug . '</h2>'; 
	//var_dump($osp_j_check);
	if(!empty($osp_j_check)){
		$osp_output .= '<div id="osp-journal-display">';
		$args2 = array(
			'post_type' => 'submission',
			'tax_query' => array(
				array(
					'taxonomy' => 'series',
					'field' => 'slug',
					'terms' => $osp_series_slug,
					),
				),

			'meta_query' => array(
				'volume_clause' => array(
					'key' => 'osp-volume',
					), 
				'issue_clause' => array(
					'key' => 'osp-issue',
					),
				'date_clause' => array(
					'key' => 'date-created',
					),
				),
			'orderby' => array(

				'volume_clause' => 'ASC',
				'issue_clause' => 'ASC',
				'menu_order' => 'ASC',

				),
			'post_status' => 'publish',
			'no_found_rows' => true,
			'update_post_term_cache' => false,
			'post_per_post' => 50,
		);
			$osp_j_v_check = "";
			$osp_j_i_check = "";
			$osp_series_type = new WP_Query($args2);
			if ($osp_series_type->have_posts()) {
				while($osp_series_type->have_posts()) : $osp_series_type->the_post();

					global $post;
					if (($osp_j_v_check == "") || ($osp_j_v_check != get_post_meta($post->ID, 'osp-volume', true))){
						$osp_output .= '<h3> Volume ' . get_post_meta($post->ID, 'osp-volume', true) . '</h3>'; 
						$osp_j_v_check = get_post_meta($post->ID, 'osp-volume', true);
					}

					if (($osp_j_i_check == "") || ($osp_j_i_check != get_post_meta($post->ID, 'osp-issue', true))){
						$osp_output .= '<h4> Issue ' . get_post_meta($post->ID, 'osp-issue', true) . '</h4>'; 
						$osp_j_i_check = get_post_meta($post->ID, 'osp-issue', true);
					}

					$osp_output .= '<p><a href="'.  get_permalink() .'">' . get_the_title() . '</a>'; 
					$osp_authors = get_post_meta($post->ID, 'osp_author_fields', true);
					$osp_auth_output ="";
					foreach ($osp_authors as $osp_author) {
						$osp_auth_output .= ', ' . esc_attr($osp_author['first_name']) . ' ' . esc_attr($osp_author['middle_initial']) . ' ' . esc_attr($osp_author['last_name']);
					}
					$osp_auth_output = ltrim($osp_auth_output, ",");
					$osp_output .= $osp_auth_output . '</p>'; 

				endwhile;
			}
			$osp_output .= '</div>';
			wp_reset_postdata();
	}

	return $osp_output;
}

add_shortcode('display_journal', 'osp_single_journal');